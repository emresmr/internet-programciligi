// AOS init & counters
AOS.init({ once: true, duration: 700, easing: 'ease-out-cubic' });

function animateCounters(){
  document.querySelectorAll('[data-counter]').forEach(el=>{
    const target = +el.getAttribute('data-counter');
    const step = Math.max(1, Math.floor(target/120));
    let value = 0;
    const int = setInterval(()=>{
      value += step;
      if(value >= target){ value = target; clearInterval(int); }
      el.textContent = value;
    }, 12);
  });
}
let countersStarted = false;
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting && !countersStarted){
      countersStarted = true;
      animateCounters();
    }
  });
});
document.querySelectorAll('.stats').forEach(s=>observer.observe(s));


// MOBILE: close collapse on link click
document.addEventListener('DOMContentLoaded', function(){
  var navLinks = document.querySelectorAll('.navbar .collapse .nav-link');
  var collapseEl = document.querySelector('.navbar .collapse');
  if (collapseEl && navLinks.length){
    navLinks.forEach(function(a){
      a.addEventListener('click', function(){
        try{
          if (typeof bootstrap !== 'undefined' && bootstrap.Collapse){
            var c = bootstrap.Collapse.getOrCreateInstance(collapseEl);
            c.hide();
          } else {
            // fallback: toggle via class
            collapseEl.classList.remove('show');
          }
        }catch(e){}
      });
    });
  }
});
